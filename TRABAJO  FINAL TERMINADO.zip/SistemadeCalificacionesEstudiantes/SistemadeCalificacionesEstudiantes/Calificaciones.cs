﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemadeCalificacionesEstudiantes
{
    public partial class Calificaciones : Form
    {
        public Calificaciones()
        {
            InitializeComponent();
        }

        private void CargarCalificaciones()
        {
            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT 
                            CalificacionID, 
                            EstudianteID, 
                            MateriaID, 
                            Cal1, 
                            Cal2, 
                            Cal3, 
                            Cal4, 
                            Examen, 
                            Total, 
                            Clasificacion, 
                            Estado 
                         FROM Calificacion";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvCalificaciones.DataSource = dt;
            }
        }


        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEstudiante.Text) ||
        string.IsNullOrWhiteSpace(txtMateria.Text) ||
        string.IsNullOrWhiteSpace(txtExam1.Text) ||
        string.IsNullOrWhiteSpace(txtExam2.Text) ||
        string.IsNullOrWhiteSpace(txtExam3.Text) ||
        string.IsNullOrWhiteSpace(txtExam4.Text) ||
        string.IsNullOrWhiteSpace(ExamFinal.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            
            int cal1 = int.Parse(txtExam1.Text);
            int cal2 = int.Parse(txtExam2.Text);
            int cal3 = int.Parse(txtExam3.Text);
            int cal4 = int.Parse(txtExam4.Text);
            int examen = int.Parse(ExamFinal.Text);

           
            if (new[] { cal1, cal2, cal3, cal4, examen }.Any(c => c < 0 || c > 100))
            {
                MessageBox.Show("Las calificaciones deben estar entre 0 y 100.");
                return;
            }

            
            double promedio = (cal1 + cal2 + cal3 + cal4) / 4.0;
            double total = Math.Round(promedio * 0.7 + examen * 0.3, 2);

            
            string clasificacion;
            if (total >= 90) clasificacion = "A";
            else if (total >= 80) clasificacion = "B";
            else if (total >= 70) clasificacion = "C";
            else clasificacion = "F";

            
            string estado = total >= 70 ? "Aprobado" : "Reprobado";

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Calificacion 
            (EstudianteID, MateriaID, Cal1, Cal2, Cal3, Cal4, Examen, Total, Clasificacion, Estado) 
            VALUES (@EstudianteID, @MateriaID, @Cal1, @Cal2, @Cal3, @Cal4, @Examen, @Total, @Clasificacion, @Estado)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EstudianteID", int.Parse(txtEstudiante.Text));
                cmd.Parameters.AddWithValue("@MateriaID", int.Parse(txtMateria.Text));
                cmd.Parameters.AddWithValue("@Cal1", cal1);
                cmd.Parameters.AddWithValue("@Cal2", cal2);
                cmd.Parameters.AddWithValue("@Cal3", cal3);
                cmd.Parameters.AddWithValue("@Cal4", cal4);
                cmd.Parameters.AddWithValue("@Examen", examen);
                cmd.Parameters.AddWithValue("@Total", total);
                cmd.Parameters.AddWithValue("@Clasificacion", clasificacion);
                cmd.Parameters.AddWithValue("@Estado", estado);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Calificación agregada correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar calificación: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarCalificaciones();

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (dgvCalificaciones.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecciona una calificación en la lista.");
                return;
            }

           
            int calificacionID = Convert.ToInt32(dgvCalificaciones.SelectedRows[0].Cells["CalificacionID"].Value);

           
            if (string.IsNullOrWhiteSpace(txtEstudiante.Text) ||
                string.IsNullOrWhiteSpace(txtMateria.Text) ||
                string.IsNullOrWhiteSpace(txtExam1.Text) ||
                string.IsNullOrWhiteSpace(txtExam2.Text) ||
                string.IsNullOrWhiteSpace(txtExam3.Text) ||
                string.IsNullOrWhiteSpace(txtExam4.Text) ||
                string.IsNullOrWhiteSpace(ExamFinal.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            
            int cal1 = int.Parse(txtExam1.Text);
            int cal2 = int.Parse(txtExam2.Text);
            int cal3 = int.Parse(txtExam3.Text);
            int cal4 = int.Parse(txtExam4.Text);
            int examen = int.Parse(ExamFinal.Text);

           
            if (new[] { cal1, cal2, cal3, cal4, examen }.Any(c => c < 0 || c > 100))
            {
                MessageBox.Show("Las calificaciones deben estar entre 0 y 100.");
                return;
            }

            
            double promedio = (cal1 + cal2 + cal3 + cal4) / 4.0;
            double total = Math.Round(promedio * 0.7 + examen * 0.3, 2);

            
            string clasificacion;
            if (total >= 90) clasificacion = "A";
            else if (total >= 80) clasificacion = "B";
            else if (total >= 70) clasificacion = "C";
            else clasificacion = "F";

            
            string estado = total >= 70 ? "Aprobado" : "Reprobado";

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Calificacion 
                         SET EstudianteID = @EstudianteID, 
                             MateriaID = @MateriaID, 
                             Cal1 = @Cal1, 
                             Cal2 = @Cal2, 
                             Cal3 = @Cal3, 
                             Cal4 = @Cal4, 
                             Examen = @Examen, 
                             Total = @Total, 
                             Clasificacion = @Clasificacion, 
                             Estado = @Estado
                         WHERE CalificacionID = @ID";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EstudianteID", int.Parse(txtEstudiante.Text));
                cmd.Parameters.AddWithValue("@MateriaID", int.Parse(txtMateria.Text));
                cmd.Parameters.AddWithValue("@Cal1", cal1);
                cmd.Parameters.AddWithValue("@Cal2", cal2);
                cmd.Parameters.AddWithValue("@Cal3", cal3);
                cmd.Parameters.AddWithValue("@Cal4", cal4);
                cmd.Parameters.AddWithValue("@Examen", examen);
                cmd.Parameters.AddWithValue("@Total", total);
                cmd.Parameters.AddWithValue("@Clasificacion", clasificacion);
                cmd.Parameters.AddWithValue("@Estado", estado);
                cmd.Parameters.AddWithValue("@ID", calificacionID);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Calificación actualizada correctamente.");
                    else
                        MessageBox.Show("No se encontró la calificación.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar calificación: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarCalificaciones();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvCalificaciones.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecciona una calificación en la lista.");
                return;
            }

            
            int calificacionID = Convert.ToInt32(dgvCalificaciones.SelectedRows[0].Cells["CalificacionID"].Value);

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Calificacion WHERE CalificacionID = @ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", calificacionID);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Calificación eliminada correctamente.");
                    else
                        MessageBox.Show("No se encontró la calificación.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar calificación: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarCalificaciones();
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT 
                            CalificacionID, 
                            EstudianteID, 
                            MateriaID, 
                            Cal1, 
                            Cal2, 
                            Cal3, 
                            Cal4, 
                            Examen, 
                            Total, 
                            Clasificacion, 
                            Estado 
                         FROM Calificacion";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvCalificaciones.DataSource = dt;
            }

        }

        private void btnCvs_Click(object sender, EventArgs e)
        {
            if (dgvCalificaciones.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos de calificaciones para exportar.");
                return;
            }

            
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV (*.csv)|*.csv";
            sfd.FileName = "Calificaciones.csv";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                    {
                        
                        for (int i = 0; i < dgvCalificaciones.Columns.Count; i++)
                        {
                            sw.Write(dgvCalificaciones.Columns[i].HeaderText);
                            if (i < dgvCalificaciones.Columns.Count - 1)
                                sw.Write(",");
                        }
                        sw.WriteLine();

                        
                        foreach (DataGridViewRow row in dgvCalificaciones.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dgvCalificaciones.Columns.Count; i++)
                                {
                                    sw.Write(row.Cells[i].Value?.ToString());
                                    if (i < dgvCalificaciones.Columns.Count - 1)
                                        sw.Write(",");
                                }
                                sw.WriteLine();
                            }
                        }
                    }

                    MessageBox.Show("Calificaciones exportadas correctamente a CSV.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar calificaciones: " + ex.Message);
                }
            }

        }
    }
}
