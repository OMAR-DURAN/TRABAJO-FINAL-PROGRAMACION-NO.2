﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemadeCalificacionesEstudiantes
{
    public partial class Materia : Form
    {
        public Materia()
        {
            InitializeComponent();
        }

        private void CargarMateria()
        {
            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MateriaID, Nombre FROM Materia";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);


                dgvMateria.DataSource = dt;
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMateria.Text))
            {
                MessageBox.Show("Por favor, ingresa el nombre de la materia.");
                return;
            }

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Materia (Nombre) VALUES (@Nombre)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", txtMateria.Text);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Materia agregada correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar materia: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarMateria(); 


        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvMateria.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecciona una materia en la lista.");
                return;
            }

           
            int materiaID = Convert.ToInt32(dgvMateria.SelectedRows[0].Cells["MateriaID"].Value);

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Materia WHERE MateriaID = @ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", materiaID);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Materia eliminada correctamente.");
                    else
                        MessageBox.Show("No se encontró la materia.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar materia: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarMateria();

        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MateriaID, Nombre FROM Materia";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                
                dgvMateria.DataSource = dt;
            }

        }

        private void btnCvs_Click(object sender, EventArgs e)
        {
            if (dgvMateria.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos de materias para exportar.");
                return;
            }

            
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV (*.csv)|*.csv";
            sfd.FileName = "Materias.csv";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                    {
                        
                        for (int i = 0; i < dgvMateria.Columns.Count; i++)
                        {
                            sw.Write(dgvMateria.Columns[i].HeaderText);
                            if (i < dgvMateria.Columns.Count - 1)
                                sw.Write(",");
                        }
                        sw.WriteLine();

                        
                        foreach (DataGridViewRow row in dgvMateria.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dgvMateria.Columns.Count; i++)
                                {
                                    sw.Write(row.Cells[i].Value?.ToString());
                                    if (i < dgvMateria.Columns.Count - 1)
                                        sw.Write(",");
                                }
                                sw.WriteLine();
                            }
                        }
                    }

                    MessageBox.Show("Materias exportadas correctamente a CSV.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar materias: " + ex.Message);
                }


            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (dgvMateria.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecciona una materia en la lista.");
                return;
            }

            
            int materiaID = Convert.ToInt32(dgvMateria.SelectedRows[0].Cells["MateriaID"].Value);

            
            if (string.IsNullOrWhiteSpace(txtMateria.Text))
            {
                MessageBox.Show("Por favor, ingresa el nuevo nombre de la materia.");
                return;
            }

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Materia SET Nombre = @Nombre WHERE MateriaID = @ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", txtMateria.Text);
                cmd.Parameters.AddWithValue("@ID", materiaID);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Materia actualizada correctamente.");
                    else
                        MessageBox.Show("No se encontró la materia.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar materia: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarMateria(); 

        }
    }
}
