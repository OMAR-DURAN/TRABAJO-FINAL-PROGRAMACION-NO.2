﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemadeCalificacionesEstudiantes
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void estudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Estudiantes frm = new Estudiantes();
            frm.MdiParent = this;
            frm.Show();

        }


        private void materiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Materia frm = new Materia();
            frm.MdiParent = this;
            frm.Show();
        }

        private void calificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Calificaciones frm = new Calificaciones();
            frm.MdiParent = this;
            frm.Show();
        }
        
    }
}
