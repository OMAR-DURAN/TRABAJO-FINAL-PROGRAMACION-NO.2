﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemadeCalificacionesEstudiantes
{
    public partial class Estudiantes : Form
    {
        public Estudiantes()
        {
            InitializeComponent();
        }

        private void CargarEstudiantes()
        {
            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT EstudianteID, Nombre, Matricula FROM Estudiante";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                
                dgvEstudiantes.DataSource = dt;
            }
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=Sistemacalificaciones;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Estudiante";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvEstudiantes.DataSource = dt;
            }

        }



        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtMatricula.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Estudiante (Nombre, Matricula) VALUES (@Nombre, @Matricula)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Matricula", txtMatricula.Text);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Estudiante agregado correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar estudiante: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarEstudiantes(); 


        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (dgvEstudiantes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecciona un estudiante en la lista.");
                return;
            }

            
            int estudianteID = Convert.ToInt32(dgvEstudiantes.SelectedRows[0].Cells["EstudianteID"].Value);

            
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtMatricula.Text))
            {
                MessageBox.Show("Por favor, completa los campos Nombre y Matrícula.");
                return;
            }

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Estudiante SET Nombre = @Nombre, Matricula = @Matricula WHERE EstudianteID = @ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Matricula", txtMatricula.Text);
                cmd.Parameters.AddWithValue("@ID", estudianteID);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Estudiante actualizado correctamente.");
                    else
                        MessageBox.Show("No se encontró el estudiante.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar estudiante: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarEstudiantes(); 



        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvEstudiantes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecciona un estudiante en la lista.");
                return;
            }

            
            int estudianteID = Convert.ToInt32(dgvEstudiantes.SelectedRows[0].Cells["EstudianteID"].Value);

            string connectionString = @"Server=OMAR\MSSQLSERVER01;Database=SistemaCalificaciones;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Estudiante WHERE EstudianteID = @ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", estudianteID);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Estudiante eliminado correctamente.");
                    else
                        MessageBox.Show("No se encontró el estudiante.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar estudiante: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            CargarEstudiantes(); 


        }

        private void btnCvs_Click(object sender, EventArgs e)
        {
            if (dgvEstudiantes.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV (*.csv)|*.csv";
            sfd.FileName = "Estudiantes.csv";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                    {
                        
                        for (int i = 0; i < dgvEstudiantes.Columns.Count; i++)
                        {
                            sw.Write(dgvEstudiantes.Columns[i].HeaderText);
                            if (i < dgvEstudiantes.Columns.Count - 1)
                                sw.Write(",");
                        }
                        sw.WriteLine();

                        
                        foreach (DataGridViewRow row in dgvEstudiantes.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dgvEstudiantes.Columns.Count; i++)
                                {
                                    sw.Write(row.Cells[i].Value?.ToString());
                                    if (i < dgvEstudiantes.Columns.Count - 1)
                                        sw.Write(",");
                                }
                                sw.WriteLine();
                            }
                        }
                    }

                    MessageBox.Show("Datos exportados correctamente a CSV.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar: " + ex.Message);
                }


            }
        }
    }
}
